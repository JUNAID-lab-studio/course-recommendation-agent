# fuel-consumption-prediction-ecu
This project predicts real-time vehicle fuel consumption and classifies  driving behaviour (economical vs non-economical) using data from a  vehicle's Electronic Control Unit (ECU) and Machine Learning algorithms.
